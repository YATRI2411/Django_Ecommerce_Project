from django.shortcuts import render, redirect
from django.contrib.auth import authenticate, login, logout
from django.contrib.auth.models import User
from .models import Product, Cart, Category, Order, OrderItem  # Import Order and OrderItem models

def home(request):
    query = request.GET.get('q', '')
    category_id = request.GET.get('category', '')
    products = Product.objects.all()
    categories = Category.objects.all()
    if query:
        products = products.filter(name__icontains=query)
    if category_id:
        products = products.filter(category_id=category_id)
    cart_count = 0
    user_info = None
    if request.user.is_authenticated:
        cart_count = Cart.objects.filter(user=request.user).count()
        user_info = request.user
    return render(request, 'dashboard.html', {
        'products': products,
        'cart_count': cart_count,
        'user_info': user_info,
        'categories': categories,
        'selected_category': category_id,
        'search_query': query,
    })

def signup_view(request):
    if request.method == 'POST':
        username = request.POST['username']
        password = request.POST['password']
        User.objects.create_user(username=username, password=password)
        return redirect('home')
    return render(request, 'signup.html')

def login_view(request):
    if request.method == 'POST':
        username = request.POST['username']
        password = request.POST['password']
        user = authenticate(request, username=username, password=password)
        if user:
            login(request, user)
    return redirect('home')  # ✅ always redirect to home

def logout_view(request):
    logout(request)
    return redirect('home')

def add_to_cart(request, product_id):
    if request.user.is_authenticated:
        product = Product.objects.get(id=product_id)
        # Check if already in cart
        exists = Cart.objects.filter(user=request.user, product=product).exists()
        if not exists:
            Cart.objects.create(user=request.user, product=product)
    return redirect('cart')


def cart_view(request):
    user = request.user
    if not user.is_authenticated:
        return redirect('login')
    cart_items = Cart.objects.filter(user=user)
    return render(request, 'cart.html', {'cart_items': cart_items})

def remove_from_cart(request, cart_id):
    if request.user.is_authenticated:
        try:
            cart_item = Cart.objects.get(id=cart_id, user=request.user)
            cart_item.delete()
        except Cart.DoesNotExist:
            pass
    return redirect('cart')


def product_detail(request, product_id):
    try:
        product = Product.objects.get(id=product_id)
    except Product.DoesNotExist:
        return redirect('home')
    cart_count = 0
    if request.user.is_authenticated:
        cart_count = Cart.objects.filter(user=request.user).count()
    return render(request, 'product_detail.html', {'product': product, 'cart_count': cart_count})

def place_order(request):
    if not request.user.is_authenticated:
        return redirect('login')
    cart_items = Cart.objects.filter(user=request.user)
    if not cart_items.exists():
        return redirect('cart')
    if request.method == 'POST':
        delivery_address = request.POST.get('delivery_address', '')
        payment_method = request.POST.get('payment_method', 'Cash on Delivery')
        total = sum(item.product.price for item in cart_items)
        order = Order.objects.create(
            user=request.user,
            total=total,
            payment_method=payment_method,
            delivery_address=delivery_address,
            delivery_eta='3-7 days',
        )
        for item in cart_items:
            OrderItem.objects.create(
                order=order,
                product=item.product,
                quantity=1,
                price=item.product.price
            )
        cart_items.delete()
        return redirect('order_success', order_id=order.id)
    return render(request, 'checkout.html')

def order_success(request, order_id):
    order = Order.objects.get(id=order_id, user=request.user)
    return render(request, 'order_success.html', {'order': order})


def order_history(request):
    if not request.user.is_authenticated:
        return redirect('login')
    orders = Order.objects.filter(user=request.user).order_by('-created_at')
    return render(request, 'order_history.html', {'orders': orders})

def extra_links(request):
    return render(request, 'extra_links.html')